﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DoctorFIRE.Models;

namespace DoctorFIRE.Models
{
    public class DoctorFIREContext : DbContext
    {
        public DoctorFIREContext (DbContextOptions<DoctorFIREContext> options)
            : base(options)
        {
        }

        public DbSet<DoctorFIRE.Models.Context> Contexts { get; set; }

        public DbSet<DoctorFIRE.Models.Content> Contents { get; set; }

        public DbSet<DoctorFIRE.Models.CCbyID> CCbyIDs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Context>().ToTable("Context");
            modelBuilder.Entity<Content>().ToTable("Content");
            modelBuilder.Entity<CCbyID>().ToTable("CCbyID");
        }

    }
}
