﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DoctorFIRE.Models;
using System.Collections;

namespace DoctorFIRE.Pages.Contents
{
    public class IndexModel : PageModel
    {
        private readonly DoctorFIRE.Models.DoctorFIREContext _context;

        public IndexModel(DoctorFIRE.Models.DoctorFIREContext context)
        {
            _context = context;
        }

        public IList<Content> Contents { get; set; }
        public IList<CCbyID> CCbyIDs { get; set; }

        public IDictionary<String, int> Sorted { get; set; }

        int ContextIDcarry { get; set; }
        

        public async Task OnGetAsync()
        {

            CCbyIDs = await _context.CCbyIDs.ToListAsync();

            if (ContextIDcarry != 0)
            {

                Dictionary<int, int> Dict = new Dictionary<int, int>();



                foreach (CCbyID ContentID in CCbyIDs)
                {

                    if (ContentID.ContextIDD == ContextIDcarry)
                    {



                        int item1 = ContentID.ContentID;
                        int item2 = ContentID.ClickCount;

                        Dict.Add(item1, item2);



                    }
                }

                Dictionary<string, int> Dict2 = new Dictionary<string, int>();


                foreach (Content content in Contents)
                {
                    Dict2.Add(content.ContentText, Dict[content.ContentIDDD]);
                }

                Sorted = Dict2.OrderBy(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            }




        }
    }
}
