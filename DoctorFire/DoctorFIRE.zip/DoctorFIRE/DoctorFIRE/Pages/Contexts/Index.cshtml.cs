﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DoctorFIRE.Models;

namespace DoctorFIRE.Pages.Contexts
{
    public class IndexModel : PageModel
    {
        private readonly DoctorFIRE.Models.DoctorFIREContext _context;

        public IndexModel(DoctorFIRE.Models.DoctorFIREContext context)
        {
            _context = context;
        }

        public IList<Context> Context { get;set; }
        public Context ContextSelected { get; set; }
        public int ContentMax { get; set; }
        public int ContextIDcarry { get; set; }

        
        public async Task OnGetAsync()
        {
            Context = await _context.Contexts.ToListAsync();
            int ContentMax = await _context.Contents.CountAsync();

  
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            ContextSelected = await _context.Contexts.FirstOrDefaultAsync(m => m.ContextID == id);

            //Update ClickCount and direct to Content page. 

            ContextIDcarry = id;


                if (await TryUpdateModelAsync<Context>(
                ContextSelected,
                 "count",
                c => c.ContextName, c => c.ContextRank + 1))
                {
                    await _context.SaveChangesAsync();
                    return RedirectToPage("Content/Index");
                }




            return Page();
        }



    }
}
