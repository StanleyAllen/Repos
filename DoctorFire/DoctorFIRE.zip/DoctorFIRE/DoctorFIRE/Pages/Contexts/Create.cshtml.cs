﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using DoctorFIRE.Models;

namespace DoctorFIRE.Pages.Contexts
{
    public class CreateModel : PageModel
    {
        private readonly DoctorFIRE.Models.DoctorFIREContext _context;

        public CreateModel(DoctorFIRE.Models.DoctorFIREContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Context Context { get; set; }
        public ICollection<CCbyID> CCbyIDCollection { get; set; }
        public int ContentMax { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            var emptyContext = new Context();


            //Create CCbyID x ContentMax
            for (int i = 0; i < ContentMax; i++)
            {
                var CCbyIDbyC = new CCbyID();
                CCbyIDbyC.ContextIDD = Context.ContextID;
                CCbyIDbyC.ContentID = 0;
                CCbyIDbyC.ContentIDD = i;
                CCbyIDbyC.ClickCount = 0;


                if (await TryUpdateModelAsync<CCbyID>(
                CCbyIDbyC,
                 "count",
                c => c.ClickCount, c => c.ContentIDD, c => c.ContextIDD, c => c.ContentID))
                {
                    await _context.SaveChangesAsync();
                }
            }
            emptyContext.CCbyIDbyC = CCbyIDCollection;
            emptyContext.ContextRank = 1;

            if (await TryUpdateModelAsync<Context>(
                emptyContext,
                "context",   // Prefix for form value.
                c => c.ContextName))
            {
                _context.Contexts.Add(emptyContext);
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }

            return Page();
        }
    }
}