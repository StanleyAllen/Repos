﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DoctorFIRE.Models
{
    public class Context
    {

        [Key]
        public int ContextID { get; set; }
        public string ContextName { get; set; }
        public int ContextRank { get; set; }
        public ICollection<CCbyID> CCbyIDbyC { get; set; }
        
    }
}
