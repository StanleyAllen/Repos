﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DoctorFIRE.Models
{

    public enum heat
    {
        orange, Red, Blue
    }


    public class Content
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int ContentIDDD { get; set; }
        public string ContentText { get; set; }
        public heat heatlevel { get; set; } 
        public string Reference { get; set; }


    }
}
